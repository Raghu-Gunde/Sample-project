

// creating Category Table

create table categoryTeam1(categoryId INTEGER UNSIGNED NOT NULL auto_increment,categoryName VARCHAR(45) NOT NULL,PRIMARY KEY(categoryID));


// creating Product Table
create table productTeam1( productId integer unsigned not null auto_increment, productName varchar(45) not null,productDesc varchar(100),brandName varchar(25),price integer unsigned not null,stock integer,image longtext not null, categoryId integer unsigned not null,primary key (productId), constraint fk_cateid_team1 foreign key fk_cateid_team1(categoryId) references categoryTeam1(categoryId) ON DELETE CASCADE ON UPDATE CASCADE) ;

//creating role table
create table roleTeam1(roleId INTEGER unsigned not null,primary key(roleId)); 


// creating Customer Table

create table userTeam1(roleId INTEGER unsigned not null ,name varchar(30) not null,address varchar(50) not null,email varchar(40) unique not null,password varchar(50) not null,phoneNo BIGINT,PRIMARY KEY(phoneNo),constraint fk_roleid_team1 foreign key fk_roleid_team1(roleId) references roleTeam1(roleId) ON DELETE CASCADE ON UPDATE CASCADE);

// Creating a CART Table

create table cartTeam1(cartId integer unsigned not null auto_increment,phoneNo BIGINT,  primary key(cartId),constraint fk_phoneNo_team1 foreign key fk_phoneNo_team1(phoneNo) references userTeam1(phoneNo) ON DELETE CASCADE ON UPDATE CASCADE);

//Creating productQty

create table productQtyTeam1(productQtyId INTEGER unsigned not null,
Qty INTEGER unsigned not null,
Amount DOUBLE unsigned not null,
cartId integer unsigned not null,
categoryId INTEGER unsigned NOT NULL,
productId integer unsigned not null,
primary key(productQtyId), 
constraint fk_cartid_team1 foreign key fk_cartid_team1(cartId) references cartTeam1(cartId) ON DELETE CASCADE ON UPDATE CASCADE,
constraint fk_pdtid_team1 foreign key(productId) references productTeam1(productId) ON DELETE CASCADE ON UPDATE CASCADE,
constraint fk_cateid_prdqty foreign key fk_cateid_prdqty(categoryId) references categoryTeam1(categoryId)ON DELETE CASCADE ON UPDATE CASCADE);



