DELIMITER $$

DROP PROCEDURE IF EXISTS deleteUser $$
CREATE PROCEDURE deleteUser(in p_phoneNO INTEGER) 
BEGIN
 
delete from userteam1  where phoneNo=p_phoneNo;
END $$

DELIMITER ;