DELIMITER $$

DROP PROCEDURE IF EXISTS deleteProduct $$
CREATE PROCEDURE deleteProduct(in p_productId INTEGER) 
BEGIN
 
delete from productTeam1  where productId=p_productId;
END $$

DELIMITER ;

