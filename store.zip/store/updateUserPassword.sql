DELIMITER $$

DROP PROCEDURE IF EXISTS updateUserPassword $$
CREATE PROCEDURE updateUserPassword(in u_password varchar(50),in u_phoneNo bigint(20))

BEGIN
 
update userteam1 set password=u_password where phoneNo=u_phoneNo;END $$

DELIMITER ;