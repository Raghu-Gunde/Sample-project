DELIMITER $$

DROP PROCEDURE IF EXISTS addproductqtyteam1 $$
CREATE PROCEDURE addproductqtyteam1 (in p_Qty integer,in p_Amount double,in p_cartId integer,in p_categoryId integer,in p_productId integer)

BEGIN
 
insert into productqtyteam1(Qty,Amount,cartId,categoryId,productId) values(p_Qty,p_Amount,p_cartId,p_categoryId,p_productId);
END $$

DELIMITER ;