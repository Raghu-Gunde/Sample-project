DELIMITER $$

DROP PROCEDURE IF EXISTS adduserteam1 $$
CREATE PROCEDURE adduserteam1 (in u_roleId INTEGER(10),in u_name varchar(30),in u_address varchar(30),in u_email varchar(40),in u_password varchar(50),in u_phoneNo bigint)
BEGIN
 insert into userteam1 values(u_roleId,u_name,u_address,u_email,u_password,u_phoneNo);

END $$

DELIMITER ;