DELIMITER $$

DROP PROCEDURE IF EXISTS addCategory $$
CREATE PROCEDURE addCategory(in c_categoryId INTEGER,in c_categoryName VARCHAR(45))
BEGIN
 
insert into categoryTeam1 values(c_categoryId,c_categoryName);

END $$

DELIMITER ;