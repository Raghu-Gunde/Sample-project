DELIMITER $$

DROP PROCEDURE IF EXISTS searchByCategoryName $$
CREATE PROCEDURE searchByCategoryName(IN p_categoryName varchar(45) , OUT p_productId INTEGER ,OUT p_productName varchar(45),OUT p_productDesc varchar(100),OUT p_brandName varchar(25),OUT p_price integer,OUT p_stock integer,OUT p_categoryId INTEGER)

BEGIN
select productId,productDesc,brandName,price ,stock,categoryId into p_productId,p_productName ,p_productDesc ,p_brandName ,p_price ,p_stock from productteam1 where productteam1.categoryId=(select  categoryId from categoryteam1 where categoryName=p_categoryName);
END $$

DELIMITER ;