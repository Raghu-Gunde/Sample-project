package com.virtusa.shopping.implementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Customer;

public class CustomerImpl implements CustomerDao{
	private Connection conn;
    private PreparedStatement ps;
    private Statement st; 
    private ResultSet rs;
	@Override
	public int saveCustomerInfo(Customer custom) {
		// TODO Auto-generated method stub
		int i=0;
		try{			
		    conn=MySqlHelper.getConnection();
		    String sql="insert into userteam1 values(?,?,?,?,?,?)";		    
		    ps = conn.prepareStatement(sql);
		    ps.setInt(1, custom.getRoleId());
		    ps.setString(2, custom.getName());
		    ps.setString(4, custom.getEmail());
		    ps.setString(3, custom.getAddress());
		    ps.setString(5, custom.getPassword());
		    ps.setLong(6, custom.getPhoneNo());
		    i = ps.executeUpdate();
		    
		}catch(Exception se){
			System.out.println("Message  :" +se.getMessage());
		}
		return i;
	}

	@Override
	public Customer getCustomerInfo(long phone) {
		// TODO Auto-generated method stub
		Customer cust = new Customer();
		try {
			conn = MySqlHelper.getConnection();
			String sql ="select * from userteam1 where phoneNo="+phone+";";
			st = conn.createStatement();
			rs =st.executeQuery(sql);
			if(rs.next()){
				
				cust.setRoleId(rs.getInt(1));
				cust.setName(rs.getString(2));
				cust.setAddress(rs.getString(3));
				cust.setEmail(rs.getString(4));
				cust.setPassword(rs.getString(5));
				cust.setPhoneNo(rs.getLong(6));
			    
			}
	    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cust;
	}

	@Override
	public int updateCustomer(Customer customer) {
		int res;
        try {
           
         
            conn = MySqlHelper.getConnection();
           String update="UPDATE userteam1 SET name=?, address=?, email=?, password=? WHERE phoneNo=?";
            ps = conn.prepareStatement(update);

           ps.setString(1, customer.getName());
           ps.setString(3, customer.getEmail());
           ps.setString(4, customer.getPassword());
           ps.setString(2, customer.getAddress());
           ps.setLong(5, customer.getPhoneNo());
           
          res= ps.executeUpdate();
           ps.close();

         

       } catch (SQLException e) {
           //e.printStackTrace();
           throw new RuntimeException(e);
       }
   return res;
       
   }
	
}


