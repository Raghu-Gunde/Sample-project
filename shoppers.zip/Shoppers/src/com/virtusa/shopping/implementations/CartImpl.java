package com.virtusa.shopping.implementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.helpers.MySqlHelper;

public class CartImpl implements CartDao {
	private Connection conn;
	private PreparedStatement pre;
	int i;
	@Override
	public int createCart(long phone) throws SQLException {
		// TODO Auto-generated method stub
		    conn=MySqlHelper.getConnection();
		    pre=conn.prepareStatement("insert into cartteam1 (phoneNo)values(?)");
		    pre.setLong(1, phone);
		     i=pre.executeUpdate();
		    return i;
	}
	@Override
	public void addToCart(int productId) {
		// TODO Auto-generated method stub
		conn = MySqlHelper.getConnection();
		
		
		
	}

}
