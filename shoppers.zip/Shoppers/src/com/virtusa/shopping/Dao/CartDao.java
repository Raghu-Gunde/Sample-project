package com.virtusa.shopping.Dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.models.ProductQty;

public interface CartDao {
	
		  
	    public int createCart(long phone)throws SQLException;
	    public int addToCart(ProductQty productQty);
	    public int updateCart(ProductQty productQty);
	    public List<ProductQty> getCart(long phoneNo);	
	    public int  deleteCart(ProductQty productQty);
	   
	}
	


