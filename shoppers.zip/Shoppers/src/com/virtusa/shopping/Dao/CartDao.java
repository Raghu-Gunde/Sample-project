package com.virtusa.shopping.Dao;

import java.sql.SQLException;

import com.virtusa.shopping.models.Product;

public interface CartDao {
	
		  
	    public int createCart(long phone)throws SQLException;
	    public void addToCart(int productId);
	}
	


