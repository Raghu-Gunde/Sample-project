package com.virtusa.shopping.Dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Product;

public interface ProductDao {
	public int saveProductInfo(Product product);
	public List<Product> getAllProducts() throws SQLException ;
	public List<Product> getProductById(int productId);
	public int  updateProduct(Product product);
	public int  deleteProduct(Product product);
}
