package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.implementations.CartImpl;
import com.virtusa.shopping.models.ProductQty;

/**
 * Servlet implementation class AddProductToCart
 */
@WebServlet("/AddProductToCart")
public class AddProductToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection conn;
	private PreparedStatement ps;
	private CallableStatement callable;
	private ResultSet rs;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddProductToCart() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//creating object for ProductQty model class
		ProductQty productQty = new ProductQty();
		//fetching the details from form
		long phoneNo = Long.parseLong(request.getParameter("phoneNo"));
		int productId = Integer.parseInt(request.getParameter("productId"));
		int qty = Integer.parseInt(request.getParameter("quantity"));
        int cartId =0;
        int i =0;
        PrintWriter out = response.getWriter();
        
		
        try { 
			  conn = MySqlHelper.getConnection();			  
			  ps =conn.prepareStatement("select cartId from cartteam1 where phoneNo ="+phoneNo);
			  rs = ps.executeQuery(); 
			  rs.next();
			  cartId = rs.getInt(1);	  
        
			
			  callable =conn.prepareCall("{call searchByProductId(?)}");
			  callable.setInt(1,productId);
			  rs=callable.executeQuery();
			  while(rs.next()) 
			   {
				  
				  		  		
				  productQty.setProductId(rs.getInt(1)); productQty.setAmount(rs.getDouble(5));
				  productQty.setCategoryId(rs.getInt(8)); productQty.setQty(qty);
				  productQty.setCartId(cartId);
				 
			  
			    } 
			   
			     CartDao cartDao = new CartImpl();
			  
			     i =cartDao.addToCart(productQty);		  			  
			  
			     if(i >0)
			     {
					  out.println("<script>alert('Product Added successfully to your cart');\nwindow.location.href='addproduct.jsp'</script>");
				  }
				  else
				  {
					  out.println("<script>alert('Product Failed to Add to Cart');\nwindow.location.href='addproduct.jsp'</script>");
				  }
			  
			  
			} 
			catch (SQLException e)
			  { // TODO Auto-generated catch block
			   e.printStackTrace();
			  }
        
	}
}
