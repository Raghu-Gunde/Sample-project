package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.implementations.CustomerImpl;
import com.virtusa.shopping.models.Customer;

/**
 * Servlet implementation class EditAccountServlet
 */
@WebServlet("/EditAccountServlet")
public class EditAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        Long phone=(Long) request.getSession(false).getAttribute("usession");
        int res;
        PrintWriter out=response.getWriter();
        Customer customer=new Customer();
                
        
        customer.setName(request.getParameter("name"));
        customer.setAddress(request.getParameter("address"));
        customer.setEmail(request.getParameter("email"));
        customer.setPassword(request.getParameter("apassword"));
        customer.setPhoneNo(phone);
        CustomerDao dao=new CustomerImpl();

 

        
    
        res=dao.updateCustomer(customer);
        if(res>0)
            out.println("<script>alert('updated successfully');\nwindow.location.href='account.jsp'</script>");
    }

 

}
