package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.implementations.CustomerImpl;
import com.virtusa.shopping.models.Customer;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Customer custom = new Customer();
		custom.setRoleId(2);
		custom.setName(request.getParameter("name"));
		custom.setAddress(request.getParameter("address"));
		custom.setEmail(request.getParameter("email"));
		custom.setPassword(request.getParameter("apassword"));
		custom.setPhoneNo(Long.parseLong(request.getParameter("aphoneno")));
		CustomerDao c = new CustomerImpl();
		PrintWriter out = response.getWriter();
		int res=c.saveCustomerInfo(custom);
		if(res>0){
			out.println("<script>alert('Registred successfully');\nwindow.location.href='shoppershome.jsp'</script>");
		}
		else{
			out.println("<script>alert('Failed to Registred');\nwindow.location.href='shoppershome.jsp'</script>");
		}
	}		

}
