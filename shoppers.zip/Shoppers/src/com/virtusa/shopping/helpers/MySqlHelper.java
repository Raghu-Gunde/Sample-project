package com.virtusa.shopping.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class MySqlHelper {
	 private static Connection conn;
	    
	 public static Connection getConnection()
	 {
	     ResourceBundle rb=ResourceBundle.getBundle("com/virtusa/shopping/resources/db");
	     String username=rb.getString("user");
	     String password=rb.getString("password");
	     String url=rb.getString("url");
	     String drivername=rb.getString("driver");
	     try {
	         Class.forName(drivername);
	         try {
	             conn = DriverManager.getConnection(url, username, password);
	         } catch (SQLException e) {
	             // TODO Auto-generated catch block
	             e.printStackTrace();
	         }
	     } catch (ClassNotFoundException e) {
	         // TODO Auto-generated catch block
	       
	       e.printStackTrace();
	     }
	      
	     return conn;
	     
	 }
}
