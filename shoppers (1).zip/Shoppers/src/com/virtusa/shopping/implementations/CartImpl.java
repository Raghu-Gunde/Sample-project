package com.virtusa.shopping.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.models.ProductQty;

public class CartImpl implements CartDao {
	private Connection conn;
	private PreparedStatement pre;
	private CallableStatement callable;
	private ResultSet rs ;
	int i;
	@Override
	public int createCart(long phone) throws SQLException {
		// TODO Auto-generated method stub
		    conn=MySqlHelper.getConnection();
		    pre=conn.prepareStatement("insert into cartteam1 (phoneNo) values(?)");
		    pre.setLong(1, phone);
		     i=pre.executeUpdate();
		    return i;
	}
	@Override
	public int addToCart(ProductQty productQty) {
		int i =0;
		try {
			conn = MySqlHelper.getConnection();			
			callable = conn.prepareCall("{call addproductqtyteam1(?,?,?,?,?)}");
			//pre =conn.prepareStatement("insert into productqtyteam1(qty,amount,cartId,categoryId,productId) values(?,?,?,?,?)");
			callable.setInt(1, productQty.getQty());
			callable.setDouble(2, productQty.getAmount());
			callable.setInt(3, productQty.getCartId());
			callable.setInt(4, productQty.getCategoryId());
			callable.setInt(5, productQty.getProductId());
			i =callable.executeUpdate();
			
		}
		catch(SQLException e)
		{
			System.out.println("Message : "+e);
		}
		
	return i;	
		
	}
	@Override
	public List<ProductQty> getCart(long phoneNo) {
		// TODO Auto-generated method stub
		  ProductQty productQty;
		  List<ProductQty> productQtyList=new ArrayList<ProductQty>();
		  try
		  {
			  conn = MySqlHelper.getConnection();
			  callable = conn.prepareCall("{call searchByCartId(?)}");
			  callable.setLong(1, phoneNo);
			  rs = callable.executeQuery();
			  while(rs.next())
			  {
				  productQty = new ProductQty();
				  productQty.setProductQtyId(rs.getInt(1));
				  productQty.setQty(rs.getInt(2));
				  productQty.setAmount(rs.getDouble(3));
				  productQty.setCartId(rs.getInt(4));
				  productQty.setCategoryId(rs.getInt(5));
				  productQty.setProductId(rs.getInt(6));
				  productQtyList.add(productQty);
				 
			  }
		  }
		  catch(SQLException e)
		  {
			  System.out.println("Exception : "+e);
		  }
		
		return null;
	}

}
