package com.virtusa.shopping.Dao;

import com.virtusa.shopping.models.Customer;

public interface CustomerDao {
	public int saveCustomerInfo(Customer custom);
	public Customer getCustomerInfo(long phone);
}
